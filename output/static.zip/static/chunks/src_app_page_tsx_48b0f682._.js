(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7f5006bb._.js",
  "static/chunks/src_75ba8069._.js"
],
    source: "dynamic"
});
